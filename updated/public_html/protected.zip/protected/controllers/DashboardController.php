<?php

class DashboardController extends Controller {

    public function beforeAction($action) {
        if (parent::beforeAction($action)) {
            if (!Yii::app()->user->checkAccess('free') && $action->id != 'index')
                $this->redirect('/');

            return true;
        }

        return false;
    }

    public function init() {
        $this->layout = '//layouts/dashboard';
        parent::init();
    }

    public function actionIndex() {

        //1 select users
        //$users = new User;
        //$users = User::model()->findAll(array('condition'=>"role=:role", 'params'=>array(":role"=>$role), 'order'=>'fio', 'limit'=>'10', 'offset'=>'15'));
        //$student = Student::model()->with('records')->findByPk($id);
        //die('model');

        $users = Users::model()->with('images')->with('location')->findAll(array(
            'select' => 't.id, t.username, t.gender',
            'condition' => 'location.city="Kyiv"',
            'limit' => '9'
                )
        );
        //die('model1');
        //echo '<pre>'; var_dump($users[0]->images); echo '</pre>';die();
        //die('11111');
//                $modelProfiles = new Profiles;
//
//                $perPage = 20;
//
//                $page = (isset($_REQUEST['page'])) ? intval($_REQUEST['page']) : 1;
//                $page = ($page) ? $page : 1;
//                $page--;
//                $profiles = $modelProfiles->Search($model->attributes, $page, $perPage);
//
//                $pages = new CPagination($profiles['count']);
//                $pages->pageSize = $perPage;
//                $pages->setCurrentPage($page);


        if (!Yii::app()->user->checkAccess('free')) {

            if (
                    Yii::app()->user->id &&
                    Yii::app()->user->Profile->getDataValue('role') == 'justjoined' &&
                    Yii::app()->user->Profile->getDataValue('ext', 'facebook')
            ) {
                $this->redirect('/site/registrationStep2');
            } else {
                //die('no profiles');
                $this->layout = '//layouts/guest-home';
                $this->render('home-guest', array('users' => $users));
            }
        } else {//if userAcces is not 'free'
            //die('dashboard is not free');
            $this->render(
                    'index', array(
                'model' => $model,
                'profiles' => $profiles['list'],
                'pages' => $pages,
                'perPage' => $perPage
                    )
            );
        }


        /* $model=new HelpForm;

          if(isset($_POST['HelpForm']))
          {
          $model->attributes=$_POST['HelpForm'];

          if($model->validate() && $model->save())
          {
          $success = "Message sent!";
          Yii::app()->user->setFlash('HelpSuccess',$success);
          }
          } */

        //$this->render('index'/*, array('model'=>$model)*/);
    }

    public function actionMatches() {
        $this->render('matches'/* , array('model'=>$model) */);
    }

    public function actionInbox() {
        $this->render('inbox'/* , array('model'=>$model) */);
    }

    public function actionInboxAll() {
        $this->render('inboxAll'/* , array('model'=>$model) */);
    }

    public function actionSent() {
        $this->render('sent'/* , array('model'=>$model) */);
    }

    public function actionHotList() {
        $this->render('hotlist'/* , array('model'=>$model) */);
    }

}