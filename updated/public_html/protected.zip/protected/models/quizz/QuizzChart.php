<?php

/**
 * Will be replaced by client QuizzChart
 *
 */
class QuizzChart
{
	private $minX = -5;
	private $maxX = 5;
	
	public function __construct($array){
	}
}