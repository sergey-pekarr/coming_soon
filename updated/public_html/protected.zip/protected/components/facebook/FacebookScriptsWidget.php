<?php
class FacebookScriptsWidget extends CWidget
{
    
    public function init()
    {
        //$facebook = Yii::app()->facebook;
        $this->render('FacebookScripts'/*, array('facebook'=>$facebook)*/);
    }
}
?>
