<?php
class QuizzMenuItemWidget extends CWidget
{	
	public function init()
	{
	}
	
	public function run(){
		$this->render('quizzmenuitem', array());
	}
}