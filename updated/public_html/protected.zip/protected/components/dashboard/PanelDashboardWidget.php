<?php
class PanelDashboardWidget extends CWidget
{
    public function init()
    {
        //$model = new LoginForm;
                
        $this->render('PanelDashboard');
    }
}
?>
