<!--
	<span id="sidebar-fan">
		<p class="activityselect">
			<img style="margin-top: 0px;" class="iconSnoopy" src="/images/img/quizz_icon.png">
			<strong>Fan</strong> | <span></span></p>							
	    <li><img class="iconSnoopy" src="/images/img/quizz1_icon.png"><a title="Manage" href="/fan/">Manage</a><span></span>
		</li>					
	    <li><img class="iconSnoopy" src="/images/img/quizz1_icon.png"><a title="Report" href="/fan/create">Report</a><span></span>
		</li>
		<li class="spacer"></li>		        			
	</span>
	
-->

<li>
	<img style="width:16px; height: 16px;" class="iconflirtandgetpaid" alt="Flirt and get paid" src="/images/img/join.png"><a title="Fan information"
		href="/fan" onclick=""><strong>Fan information</strong></a><span style="color:red"></span></li>