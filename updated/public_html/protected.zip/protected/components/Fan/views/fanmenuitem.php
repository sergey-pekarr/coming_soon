<li>
	<img style="width:16px; height: 16px;" class="iconflirtandgetpaid" alt="Flirt and get paid" src="/images/img/join.png"><a title="Flirt and get paid"
		href="/fan" onclick=""><strong>Flirt and get paid</strong></a><span style="color:red"></span></li>