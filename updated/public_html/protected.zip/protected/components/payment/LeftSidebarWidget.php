<?php
class LeftSidebarWidget extends CWidget
{
	public $paymod;
	
	public function init()
    {
        $this->render('leftSidebar', array());
    }
}
?>
