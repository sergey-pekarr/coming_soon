<?php
class FooterWidget extends CWidget
{
    public $paymode;
	
	public function init()
    {
        /*if (Yii::app()->user->id && Yii::app()->user->Profile->getDataValue('username')=='tester')
        	$this->paymode = 'segpay';
    	
    	if ($this->paymode == 'segpay')*/
		
///    		$this->render('footerSegpay');

    }
}
?>
