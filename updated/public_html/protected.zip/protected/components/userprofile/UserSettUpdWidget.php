<?php
class UserSettUpdWidget extends CWidget
{
    public function init()
    {
        $this->render('UserSettUpd');
    }
}
?>
