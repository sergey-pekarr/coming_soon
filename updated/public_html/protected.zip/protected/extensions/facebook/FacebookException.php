<?php
/*
 * This product includes software developed by
 * Ismail Elshareef (http://about.me/ismailelshareef)
 * under Apache 2.0 License (http://www.apache.org/licenses/LICENSE-2.0.html).
 *
 */
class FacebookException extends CException {
}