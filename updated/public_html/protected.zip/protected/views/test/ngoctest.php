<?php

foreach($data as $key => $value){
	echo "$key/$value<br/>";
}

print_r($data);

?>
