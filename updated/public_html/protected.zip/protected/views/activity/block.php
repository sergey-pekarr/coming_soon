<div style="padding-bottom: 15px;">
        <p>

        </p>
        <br>
</div>
<div class="search_results">
    <?php 
	$showLocation = false;
	$showBlockIcon = true;
	$showIcons = false;
	include dirname(__FILE__).'/userpanel.php'; ?>
</div>
