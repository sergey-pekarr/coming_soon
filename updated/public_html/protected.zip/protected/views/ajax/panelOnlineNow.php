<?php $this->widget('application.components.panel.PanelOnlineNowWidget', array('ajax'=>true, 'page'=>$page, 'all'=>$all));


