<?php
//echo '<pre>'; var_dump($users); echo '</pre>'; die('hurrah');
if (isset($_SERVER['GEOIP_CITY']))
    $city = $_SERVER['GEOIP_CITY'];
else {
    /* $location_id = Yii::app()->location->findLocationIdByIP();        
      $location = Yii::app()->location->getLocation( $location_id );
      $city = $location['city']; */
    $city = "";
}

if (!$city)
    $city = "Your Area";
?>

<div class="users">
    <ul class="profiles front">
        <?php
        //echo '<pre>'; var_dump($_SERVER); echo '</pre>';
        //echo Yii::app()->getBaseUrl(true).'<br />'; 

        if (!empty($users))
            foreach ($users as $user) {
                ?><li><div class='user_profile'><?php
                echo $user->id;
                echo '<br />';
                echo $user->username;
                echo '<br />';
                if (empty($user->images[0]->n)) {
                    if ($user->gender === 'M') {
                        $male = 'male';
                    } else {
                        $male = 'female';
                    };
                    $img = '<img src="/../../images/nophoto_' . $male . '_big.png" />';
                } else {
                    $img = $user->id . '/' . $user->images[0]->n[0] . '_big.jpg';
                }
                echo $img . '<br />';

                echo $user->gender;
                ?>
                        <div class="clear"></div>
                    </div>
                </li>
                <?php
            };
        ?>
    </ul>
</div>








