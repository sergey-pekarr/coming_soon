<?php $this->widget('application.components.userprofile.ProfilesInterestWidget', array('countNeed'=>4)); ?>


<div class="box_rs1">
    <?php //$this->widget('application.components.dashboard.PanelDashboardUpdatesWidget'); ?>
</div>

