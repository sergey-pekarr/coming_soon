<div id="award-current" onclick="showLevelup();"  class="award-header award-header-<?php echo ($level); ?>">
    <div class="award-icon-box">
        <table>
            <tr>
                <td>
                    <div class="award-icon award-icon-1">
                    </div>
                </td>
                <td>
                    <div class="award-icon award-icon-2">
                    </div>
                </td>
                <td>
                    <div class="award-icon award-icon-3">
                    </div>
                </td>
                <td>
                    <div class="award-icon award-icon-4">
                    </div>
                </td>
            </tr>
        </table>
        <div class="clear">
        </div>
    </div>
</div>