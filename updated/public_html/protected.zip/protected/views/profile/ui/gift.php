<div id="gifts_received" class="sendgift_icons">
    <div class="content_bar">
		<div class="profile-headline" style="font-weight: bold;">
        Flirts received from other members
		</div>
	</div>
    <div id="gifts_received_icons" style="padding-bottom:20px;">
        <a class="gifticon gifticon_kiss"></a>
		<a class="gifticon gifticon_rose"></a>
    </div>
	<div class="clear"></div>
</div>
