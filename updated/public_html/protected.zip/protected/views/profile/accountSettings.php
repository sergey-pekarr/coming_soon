<?php 
$this->widget('application.components.userprofile.ProfilesInterestWidget', array('countNeed'=>4));


$this->widget('application.components.userprofile.UserSettingsFormWidget');

//$this->widget('application.components.userprofile.UserUpdatesWidget', array('profile'=>Yii::app()->user->Profile));

