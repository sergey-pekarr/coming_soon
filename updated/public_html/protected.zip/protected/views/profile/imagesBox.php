<?php

$this->widget('application.components.userprofile.ProfileImagesBoxWidget');

$this->widget('application.components.img.UserImgUploadFormWidget');





