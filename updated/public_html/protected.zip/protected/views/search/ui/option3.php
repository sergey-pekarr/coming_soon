<div class="left">
    Personality:
</div>
<div class="right">
    <label class="personality[1]" for="personality[1]">
        <input id="personality[1]" class="checkbox " name="personality" value="1" type="checkbox">&nbsp;Easy&nbsp;<span></span></label>
    <label class="personality[2]" for="personality[2]">
        <input id="personality[2]" class="checkbox " name="personality" value="2" type="checkbox">&nbsp;Going&nbsp;<span></span></label>
    <label class="personality[3]" for="personality[3]">
        <input id="personality[3]" class="checkbox " name="personality" value="3" type="checkbox">&nbsp;Reserved&nbsp;<span></span></label>
    <label class="personality[4]" for="personality[4]">
        <input id="personality[4]" class="checkbox " name="personality" value="4" type="checkbox">&nbsp;Shy&nbsp;<span></span></label>
    <label class="personality[5]" for="personality[5]">
        <input id="personality[5]" class="checkbox " name="personality" value="5" type="checkbox">&nbsp;Stubborn&nbsp;<span></span></label>
    <label class="personality[6]" for="personality[6]">
        <input id="personality[6]" class="checkbox " name="personality" value="6" type="checkbox">&nbsp;Energetic&nbsp;<span></span></label>
    <label class="personality[7]" for="personality[7]">
        <input id="personality[7]" class="checkbox " name="personality" value="7" type="checkbox">&nbsp;Enthusiastic&nbsp;<span></span></label>
    <label class="personality[8]" for="personality[8]">
        <input id="personality[8]" class="checkbox " name="personality" value="8" type="checkbox">&nbsp;Adventurous&nbsp;<span></span></label>
    <label class="personality[9]" for="personality[9]">
        <input id="personality[9]" class="checkbox " name="personality" value="9" type="checkbox">&nbsp;Quiet&nbsp;<span></span></label>
    <label class="personality[10]" for="personality[10]">
        <input id="personality[10]" class="checkbox " name="personality" value="10" type="checkbox">&nbsp;Helpful&nbsp;<span></span></label>
    <label class="personality[11]" for="personality[11]">
        <input id="personality[11]" class="checkbox " name="personality" value="11" type="checkbox">&nbsp;Generous&nbsp;<span></span></label>
    <label class="personality[12]" for="personality[12]">
        <input id="personality[12]" class="checkbox " name="personality" value="12" type="checkbox">&nbsp;Spontaneous&nbsp;<span></span></label>
    <label class="personality[13]" for="personality[13]">
        <input id="personality[13]" class="checkbox " name="personality" value="13" type="checkbox">&nbsp;Confident&nbsp;<span></span></label>
    <label class="personality[14]" for="personality[14]">
        <input id="personality[14]" class="checkbox " name="personality" value="14" type="checkbox">&nbsp;Superstitious&nbsp;<span></span></label>
    <label class="personality[15]" for="personality[15]">
        <input id="personality[15]" class="checkbox " name="personality" value="15" type="checkbox">&nbsp;Thoughtful&nbsp;<span></span></label>
    <label class="personality[16]" for="personality[16]">
        <input id="personality[16]" class="checkbox " name="personality" value="16" type="checkbox">&nbsp;Carefree&nbsp;<span></span></label>
    <label class="personality[17]" for="personality[17]">
        <input id="personality[17]" class="checkbox " name="personality" value="17" type="checkbox">&nbsp;Sociable&nbsp;<span></span></label>
    <label class="personality[18]" for="personality[18]">
        <input id="personality[18]" class="checkbox " name="personality" value="18" type="checkbox">&nbsp;High
        Maintenence&nbsp;<span></span></label>
    <label class="personality[19]" for="personality[19]">
        <input id="personality[19]" class="checkbox " name="personality" value="19" type="checkbox">&nbsp;Sensitive&nbsp;<span></span></label>
    <label class="personality[20]" for="personality[20]">
        <input id="personality[20]" class="checkbox " name="personality" value="20" type="checkbox">&nbsp;Possessive&nbsp;<span></span></label>
    <label class="personality[21]" for="personality[21]">
        <input id="personality[21]" class="checkbox " name="personality" value="21" type="checkbox">&nbsp;Funny&nbsp;<span></span></label>
    <label class="personality[22]" for="personality[22]">
        <input id="personality[22]" class="checkbox " name="personality" value="22" type="checkbox">&nbsp;Reliable&nbsp;<span></span></label>
    <label class="personality[23]" for="personality[23]">
        <input id="personality[23]" class="checkbox " name="personality" value="23" type="checkbox">&nbsp;Reflective&nbsp;<span></span></label>
    <label class="personality[24]" for="personality[24]">
        <input id="personality[24]" class="checkbox " name="personality" value="24" type="checkbox">&nbsp;Other&nbsp;<span></span></label>
</div>
<hr />
<div class="left">
    Kinky:
</div>
<div class="right">
    <label class="kinky[1]" for="kinky[1]">
        <input id="kinky[1]" class="checkbox " name="kinky" value="1" type="checkbox">&nbsp;Very
        Kinky&nbsp;<span></span></label>
    <label class="kinky[2]" for="kinky[2]">
        <input id="kinky[2]" class="checkbox " name="kinky" value="2" type="checkbox">&nbsp;Kinky&nbsp;<span></span></label>
    <label class="kinky[3]" for="kinky[3]">
        <input id="kinky[3]" class="checkbox " name="kinky" value="3" type="checkbox">&nbsp;Not
        Very Kinky&nbsp;<span></span></label>
    <label class="kinky[4]" for="kinky[4]">
        <input id="kinky[4]" class="checkbox " name="kinky" value="4" type="checkbox">&nbsp;Not
        Kinky At All&nbsp;<span></span></label>
    style
</div>
<hr />
<div class="left" style="display: none;">
    Lifestyle:
</div>
<div class="right" style="display: none;">
</div>
<hr style="display: none;" />
<a href="#" onclick="changeTab('a[title=\'option4\']'); return false;" class="content_button"
    style="width: auto;">Search Tastes<span><img class="iconForward" src="/images/img/blank.gif"
        alt="" /></span></a>