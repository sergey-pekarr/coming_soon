<div class="left">
    Oral:
</div>
<div class="right">
    <label class="oral[1]" for="oral[1]">
        <input id="oral[1]" class="checkbox " name="oral" value="1" type="checkbox">&nbsp;Giving&nbsp;<span></span></label>
    <label class="oral[2]" for="oral[2]">
        <input id="oral[2]" class="checkbox " name="oral" value="2" type="checkbox">&nbsp;Receiving&nbsp;<span></span></label>
    <label class="oral[3]" for="oral[3]">
        <input id="oral[3]" class="checkbox " name="oral" value="3" type="checkbox">&nbsp;Both&nbsp;<span></span></label>
    <label class="oral[4]" for="oral[4]">
        <input id="oral[4]" class="checkbox " name="oral" value="4" type="checkbox">&nbsp;Neither&nbsp;<span></span></label>
</div>
<hr />
<div class="left">
    Anal:
</div>
<div class="right">
    <label class="anal[1]" for="anal[1]">
        <input id="anal[1]" class="checkbox " name="anal" value="1" type="checkbox">&nbsp;Giving&nbsp;<span></span></label>
    <label class="anal[2]" for="anal[2]">
        <input id="anal[2]" class="checkbox " name="anal" value="2" type="checkbox">&nbsp;Receiving&nbsp;<span></span></label>
    <label class="anal[3]" for="anal[3]">
        <input id="anal[3]" class="checkbox " name="anal" value="3" type="checkbox">&nbsp;Both&nbsp;<span></span></label>
    <label class="anal[4]" for="anal[4]">
        <input id="anal[4]" class="checkbox " name="anal" value="4" type="checkbox">&nbsp;Neither&nbsp;<span></span></label>
</div>
<hr />
<div class="left">
    Experience:
</div>
<div class="right">
    <label class="experience[1]" for="experience[1]">
        <input id="experience[1]" class="checkbox " name="experience" value="1" type="checkbox">&nbsp;Very
        Experienced&nbsp;<span></span></label>
    <label class="experience[2]" for="experience[2]">
        <input id="experience[2]" class="checkbox " name="experience" value="2" type="checkbox">&nbsp;Experienced&nbsp;<span></span></label>
    <label class="experience[3]" for="experience[3]">
        <input id="experience[3]" class="checkbox " name="experience" value="3" type="checkbox">&nbsp;Need
        Some Practice&nbsp;<span></span></label>
    <label class="experience[4]" for="experience[4]">
        <input id="experience[4]" class="checkbox " name="experience" value="4" type="checkbox">&nbsp;Inexperienced&nbsp;<span></span></label>
</div>
<hr />
<a href="#" onclick="changeTab('a[title=\'option5\']'); return false;" class="content_button"
    style="width: auto;">Search Habits<span><img class="iconForward" src="/images/img/blank.gif"
        alt="" /></span></a>