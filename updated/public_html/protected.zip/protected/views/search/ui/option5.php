<div class="left">
    Smoking:
</div>
<div class="right">
    <label class="smoking[1]" for="smoking[1]">
        <input id="smoking[1]" class="checkbox " name="smoking" value="1" type="checkbox">&nbsp;No
        Way&nbsp;<span></span></label>
    <label class="smoking[2]" for="smoking[2]">
        <input id="smoking[2]" class="checkbox " name="smoking" value="2" type="checkbox">&nbsp;Occasionally&nbsp;<span></span></label>
    <label class="smoking[3]" for="smoking[3]">
        <input id="smoking[3]" class="checkbox " name="smoking" value="3" type="checkbox">&nbsp;Cigars&nbsp;<span></span></label>
    <label class="smoking[4]" for="smoking[4]">
        <input id="smoking[4]" class="checkbox " name="smoking" value="4" type="checkbox">&nbsp;Trying
        To Quit&nbsp;<span></span></label>
    <label class="smoking[5]" for="smoking[5]">
        <input id="smoking[5]" class="checkbox " name="smoking" value="5" type="checkbox">&nbsp;Daily&nbsp;<span></span></label>
</div>
<hr />
<div class="left">
    Drinking:
</div>
<div class="right">
    <label class="drinking[1]" for="drinking[1]">
        <input id="drinking[1]" class="checkbox " name="drinking" value="1" type="checkbox">&nbsp;Never&nbsp;<span></span></label>
    <label class="drinking[2]" for="drinking[2]">
        <input id="drinking[2]" class="checkbox " name="drinking" value="2" type="checkbox">&nbsp;Occasionally&nbsp;<span></span></label>
    <label class="drinking[3]" for="drinking[3]">
        <input id="drinking[3]" class="checkbox " name="drinking" value="3" type="checkbox">&nbsp;Daily&nbsp;<span></span></label>
</div>

