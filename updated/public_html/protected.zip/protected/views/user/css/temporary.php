<?php
//n: temporary add style here to help development easier. will be move to css folder after completely define structure
?>