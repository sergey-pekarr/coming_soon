<?php $this->beginContent(LAYOUT); ?>
<div id="wrapper">
    <?php echo $content; ?>
</div>
<?php $this->endContent(); ?>