<?php $this->beginContent(LAYOUT); ?>
<div id="wrapper">
    <div class="viewEditProfile" style="width: 980px;">
	   <?php echo $content; ?>
    </div>
</div>
<?php $this->endContent(); ?>