<?php $this->beginContent(LAYOUT); ?>
<div id="content" class="guest">
    <div id="bx-c">
	<?php echo $content; ?>
    <div class="clear">
    </div>
</div>
</div>
<?php $this->endContent(); ?>