<?php 
//dashboard ~ member: has been designed

include dirname(__FILE__).'/member.php';
?>