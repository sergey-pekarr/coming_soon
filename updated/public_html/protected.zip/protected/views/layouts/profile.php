<?php $this->beginContent(LAYOUT); ?>
<div id="wrapper">
    <div class="viewEditProfile">
	   <?php echo $content; ?>
    </div>
</div>
<?php $this->endContent(); ?>