<div id="foot">
    <div id="global_footer">
        <p id="global_footer_nav">
            <a href="/site/page/terms" title="Terms &amp; Conditions">Terms of use</a>
            <span>•</span>
            <a href="/site/page/privacy" title="Privacy Policy">Privacy Policy</a>
            <span>•</span>
            <a href="/site/page/contact" title="Contact">Contact</a>
            <span>•</span>
            <a href="/site/page/help" title="Help">Help</a>
            <span>•</span>
            <a href="<?php echo TICKET_URL ?>" title="Ticket">Ticket</a>
        </p>
        
        <p id="global_footer_copyr">
            Copyright 2012-<?php echo date("Y") ?> Pinkmeets.com All Rights Reserved.
		</p>
		
		<p>
			<a href="/site/page/recordkeeping">18 U.S.C. 2257 Record-Keeping Requirements Compliance Statement</a>
		</p>
		
		<?php /*
		<p style="margin-top: 20px;">
			Any charges through Segregated Payments Inc. will read <a href="https://segpaycs.com/">SEGPAYEU.COM-Pinkmeets</a> on your cardholder statement.
		</p>
		*/ ?>
		
		<?php /* //if ( Yii::app()->user->isGuest ) { ?>
		<p class="zombaio">
			<font face="tahoma" size="1">
			<!--Start Zombaio 5.6 Code-->
			<script src="https://secure.zombaio.com/External/loc-scr/?62764850w2a0eb03d9974ae572c2b6166a1429f0d"></script>
			<!--End Zombaio 5.6 Code-->
			</font>
		</p>
		<?php //} */ ?>
		<p style="color:#fff; margin-top: 10px; font-size: 11px!important">
			All charges will appear through our payment processor PKM Billing, and will read PKMBilling.com on your cardholder statement.
		</p>
		
    </div>
</div>
