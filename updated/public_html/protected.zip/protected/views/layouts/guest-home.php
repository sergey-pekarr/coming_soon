<?php $this->beginContent(LAYOUT); ?>
	
	<div class="members-map">	
	
		<div id="wrapper" >
			
			<?php echo $content; ?>
			
		</div>
		
	</div>
	
	<div class="clear"></div>
	
<?php $this->endContent(); ?>