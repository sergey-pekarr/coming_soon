<?php $this->beginContent(LAYOUT); ?>
<div id="wrapper">
	<div class="one-column">
        <?php echo $content; ?>
    </div>
</div>
<?php $this->endContent(); ?>