<div class="box_rs1" style="margin-top: 10px;">
    <?php //$this->widget('application.components.dashboard.PanelDashboardMessagesInboxWidget'); ?>
</div>


