<div class="bgRadBox">

<div class="center alert alert-warning" style="margin: 60px 100px 200px 100px; font-weight: bold; font-size: 14px;">
Your payment was declined
<br />
<a href="/">Home page</a>
</div>


</div>