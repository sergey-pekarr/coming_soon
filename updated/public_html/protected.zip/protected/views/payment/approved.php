<div class="bgRadBox">

<div class="center alert alert-success" style="margin: 60px 100px 200px 100px; font-weight: bold; font-size: 14px;">
Congratulation! Your payment was approved
<br />
<a href="/">Home page</a>
</div>


</div>