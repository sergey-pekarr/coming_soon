{
'alert':
	{
		'title':'Notification', 
		'desc':'<?php if(isset($desc)) echo $desc; ?>', 
		'content':'<div></div>'
	}
}