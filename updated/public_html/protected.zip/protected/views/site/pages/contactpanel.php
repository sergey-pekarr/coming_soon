            <div style="padding: 0px 5px 5px;" class="sbody">
<?php /*                <b>Contact us</b>
<br />


<span style="font-size:14px;">
&nbsp;&nbsp;&nbsp;&nbsp;USA/CANADA (800) ***-**-**<br />
&nbsp;&nbsp;&nbsp;&nbsp;Australia 1-800-***-**-** <br />
&nbsp;&nbsp;&nbsp;&nbsp;UK 0-808-***-**-** <br />
</span> */?>
</div>




            <div style="padding: 5px; border: 1px solid rgb(192, 192, 192);">
                <div style="padding: 20px;">

In order to streamline support requests and better serve you, we utilize a support ticket system. Every support request is assigned a unique ticket number which you can use to track the progress and responses online. For your reference we provide complete archives and history of all your support requests. 
<div style="padding-top:20px">
                    <div style="padding: 20px; text-align:center">
                        <a style="padding: 5px 20px 4px; text-decoration: none;" class="btn" onclick="this.blur();" href="<?php echo TICKET_URL ?>"><span style="color: red; font-size: 15px; font-weight: bold;">Click to submit a support request</span></a>
                    </div>

<br />
Please visit the link below if you want to cancel your membership or check your billing status. You can see the billing agent you were billed with, in the email you received with your username and password :
<?php /*
<br />
SegPay Accounts: <a target="_blank" href="https://segpaycs.com/spsolo.aspx">https://segpaycs.com/spsolo.aspx</a>
*/ ?>
<?php /*?><br />
Zombaio Accounts: <a target="_blank" href="http://support.zombaio.com/">http://support.zombaio.com/</a> */ ?>
<br /><br />
All charges will appear through our payment processor PKM Billing, and will read PKMBilling.com on your cardholder statement.
<br />
<br />
PinkMeets accounts: Submit ticket above.


</div>
                </div>
            </div>
            <br>


<br />



