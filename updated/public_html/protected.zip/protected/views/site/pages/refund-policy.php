<?php

$this->pageTitle=Yii::app()->params['site']['nameFull'] . ' - Refund Policy';
$this->breadcrumbs=array(
	'Refund Policy',
);
?>


<div id="bx-content">
    <div class="tandc">
        <div style="padding: 5px 0px; background-color: white;">
		
            <div style="padding: 5px 10px 10px;" class="sbody2">
                <b>Refund Policy</b>
            </div>
            <div style="padding: 5px; border: 1px solid rgb(192, 192, 192);">
                <div style="padding: 5px;">
PinkMeets does not provide cash refunds. Refunds to your credit card will be provided upon request. 
				</div>
            </div>
<br /><br /><br /><br />

        </div>
    </div>
    <div class="clear">
    </div>
</div>


