<div id="bx-content">
    <div class="tandc">
        <div style="padding: 5px 0px; background-color: white;">
            
            <?php include dirname(__FILE__).'/contactpanel.php'; ?>

            <div style="padding: 5px 10px 10px;" class="sbody2">
                <b>18 U.S.C. 2257 Record-Keeping Requirements Compliance Statement</b>
            </div>
            <div style="padding: 5px; border: 1px solid rgb(192, 192, 192);">
                <div style="padding: 5px;">
                    <h3>
                    </h3>
                    <p>
                        YAll models, actors, actresses and other persons that appear in any visual portrayal
                        of actual sexually explicit conduct appearing or otherwise contained in this Website
                        (pinkmeets.com) were over the age of eighteen years at the time the visual
                        image was created.</p>
                    <h3>
                    </h3>
                    <p>
                        All other visual depictions displayed on this Website are exempt from the provision
                        of 18 U.S.C. section 2257 and 28 C.F.R. 75 because said they do not portray conduct
                        as specifically listed in 18 U.S.C section 2256 (2) (A) through (d), but are merely
                        depictions of non-sexually explicit nudity, or are depictions of simulated sexual
                        conduct, or are otherwise exempt because the visual depictions were created prior
                        to July 3, 1995.</p>
                    <h3>
                    </h3>
                    <p>
                        With respect to all visual depictions displayed on this web site, whether of actual
                        sexually explicit conduct, simulated sexual conduct or otherwise, all persons were
                        at least 18 years of age when said visual depictions were created.</p>
                    <h3>
                    </h3>
                    <p>
                        The owners and operators of this Web site are not the primary producers (as that
                        term is defined in 18 U.S.C. Section 2257) of any of the visual content contained
                        in the Website (pinkmeets.com).</p>
                    <h3>
                    </h3>
                    <p>
                        The images contained on pinkmeets.com were published, republished, reproduced
                        or reissued on December 2006 This company is a proud member of the Free Speech Coalition.
                        Record of membership on file.</p>
                    <h3>
                    </h3>
                    <?php /* <p>
                        All records required to be kept by federal law are in the possession and available
                        for inspection during all reasonable hours at : C.Newnham P.O. Box
                        15442 North Palm Beach, FL 33408
					</p> */ ?>
                </div>
            </div>
            <div style="padding-top: 10px;">
            </div>
        </div>
    </div>
    <div class="clear">
    </div>
</div>