<div id="bx-content">
    <div class="tandc">
        <div style="padding: 5px 0px; background-color: white;">
            <div style="padding: 5px; border: 1px solid rgb(192, 192, 192);">
                <div style="padding: 5px 20px 20px;">
                
                    <h3 style="font-size: 16px !important;">Contact us:</h3>
                    <div style="font-weight: bold;" class="address">
						Livespace Investments Ltd.<br />
						6 Ioanni Stylianou #202, 2003<br />
						Nicosia, Cyprus<br />
                    </div>                
                <br /><br /><br />
<?php /*                    
                    <p>
                        For help with any issue please fill out the help form on the help page. To contact us by mail:
                    </p>
                    <div style="font-weight: bold;" class="address">
					USA/CANADA (800) ***-****<br>
					Australia 1-800-***-**** <br>
					UK 0-808-***-****<br>
						<br>
						************<br>
                        *************<br>
                        *****************<br>
                        *************<br>
						******<br>
						*****************<br>
						
<br />						
**********<br />
***********<br />
*******************<br />						
						
						
						<br>
						***********<br>
						****************<br>
						**************<br>
                    </div>
*/ ?>                    
                    <br>
                    Please note: if you want to receive faster response, please use <a href="<?php echo TICKET_URL ?>"><b>Contact form</b></a> instead of emailing us.

<?php /*                    
                    <br /><br /><br /><br />
                    Any charges through Segregated Payments Inc. will read <a href="https://segpaycs.com/">SEGPAYEU.COM-Pinkmeets</a> on your cardholder statement.
*/ ?>
                    <br /><br />
					<?php /*
					<font face="tahoma" size="1">
					 ?><!--Start Zombaio 5.6 Code-->
					<script src="https://secure.zombaio.com/External/loc-scr/?62764850w2a0eb03d9974ae572c2b6166a1429f0d"></script>
					<!--End Zombaio 5.6 Code-->                     
                    </font>
                    */ ?>
					<p style="margin-top: 10px; font-size: 11px!important">
						All charges will appear through our payment processor PKM Billing, and will read PKMBilling.com on your cardholder statement.
					</p>                    
                    
                    
                </div>
            </div>
        </div>
    </div>
    <div class="clear">
    </div>
</div>