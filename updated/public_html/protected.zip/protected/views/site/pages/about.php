<?php
$this->pageTitle=Yii::app()->params['site']['nameFull'] . ' - About';
$this->breadcrumbs=array(
	'About',
);
?>
<?php /* 
<div class="pageAboutUs">
	<h1>About</h1>
    
    <p style="">
        Welcome to ...
    </p>    
    
    <p class="p2">
        Any questions?
        <br /><br />
        <a href="/help" class="btn success">Contact us!</a>
    </p>

    <p class="p2" style="margin-top: 40px">
            <a href="/site/terms">Terms of Use</a>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="/site/privacy">Privacy Policy</a>
    </p>

    
*/ ?>
</div>