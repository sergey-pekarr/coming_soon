﻿
    <img alt="Snoopy's Top Tips" src="/images/img/snoopys-top-tips-header.png">
    <div class="clear">
        &nbsp;</div>
    <div style="width: 525px; float: left;" class="div_dashboard">
        <div class="article">
            <h2>
                A New Years Dating Story…</h2>
            <p class="stt-date">
                29th Dec 2011</p>
            <div>
                <p>
                    Hey Fellow viewers
                    <img class="wp-smiley" alt=":D" src="/images/img/emotions/icon_biggrin.gif">
                    ,</p>
                <p>
                    I found this awesome story and i figured it would tie in nicely with my previous
                    blog on Dating over New years.</p>
                <p>
                    So, this is what happens if you read my blogs!</p>
                <p>
                    “Happy New Years!” the crowd shouted. I couldn’t believe here it was New year’s
                    again and I still didn’t have a date, nobody to kiss. Every year I end up single
                    and instead of staying home where it won’t bother me, I end up going to a crazy
                    party filled with nothing but couples kissing and dancing. That was when I spotted
                    her, a woman about my age standing across&nbsp;the room with the same look on her
                    face that I was sure I had; loneliness. I walked over to her and smiled, she looked
                    over at me and looked relieved that someone wanted to speak to her during all of
                    this craziness.</p>
                <p>
                    <img class="size-full wp-image-82 alignleft" title="shutterstock_73278892" alt="" src="/images/img/shutterstock_73278892.jpg"></p>
                <p>
                    &nbsp;</p>
                <p>
                    “Happy New Year” I managed to shout to her. She smiled and shouted it back to me,
                    lifting her glass of champagne for a toast. After clinging glasses, she drank the
                    rest of her glass and walked closer to me, leaning in she&nbsp;said to me, “I just
                    wanted a kiss on New Years, would you kiss me?” I smiled, knowing exactly how she
                    felt. I nodded and she leaned in a started to kiss me. I expected the kind of kiss
                    that you give to your mom, but somehow she slightly opened her mouth and I slid
                    my tongue in tasting her champagne while our tongues danced in each other’s mouths.
                    When she finally pulled away from me, her cheeks were flushed and her eyes were
                    sparkling, and that was when I noticed just how beautiful she was.&nbsp;I was just
                    about to ask her for her number when she put down her empty glass and grabbed my
                    hand. She started to walk toward the open door and i followed figuring she wanted
                    to find a quieter spot to talk in. But she surprised me, she walked to a door I
                    had never noticed before and opened it, I looked inside and noticed that it was
                    a large closet filled with jackets. Wondering why she was showing me this closet,
                    she backed into it and pulled me in with her.</p>
                <br>
            </div>
        </div>
        <div class="article">
            <h2>
                New Years Dating Tips</h2>
            <p class="stt-date">
                21st Dec 2011</p>
            <div>
                <p>
                    <strong>Snoopys New Year’s Dating Tips</strong></p>
                <p>
                    <img class="size-medium wp-image-62 alignright" title="shutterstock_86028595" alt="" src="/images/img/shutterstock_86028595.jpg?w=300&amp;h=300" width="300" height="300"></p>
                <div>
                    Finding a&nbsp;date for New Year’s Eve&nbsp;is a stress that almost everyone on
                    the dating scene has experienced at one time or another in their life. Many people
                    struggle with finding the right person to take out on what is possibly one of the
                    biggest party nights of the year and often settle for anyone who is free and willing.</div>
                <p>
                    The good news is, that glowing night of champagne and noise makers is still a while
                    off, giving you plenty of time to find just the right person to share this special
                    night with. In order to boost your chances for success, it is important to address
                    some specific points about how you will spend that night and who you would ideally
                    like to spend it with (movie stars and models aside.)</p>
                <p>
                    <strong>&nbsp;Where you’ll be:</strong></p>
                <div>
                    Having a party to attend, or throw, or an event that you know you’ll want to attend
                    ahead of time allows you the opportunity to invite someone to an actual event, rather
                    than just the idea of wanting to go out. This can be extremely useful for New Years
                    singles as it helps to have a goal to shoot for when considering candidates for
                    your romantic life.</div>
                <p>
                    Making as many of your New Years Eve plans ahead of time as possible will also be
                    of great use to you later on. When you do find that special date, the last thing
                    you want is to blow it by forgetting something as trivial as having the right shoes
                    to go with your party clothes. It is also vital that you solidify your plans for
                    the night with your date, leaving anything to chance may just break your heart and
                    leave you spending New Years Eve alone.</p>
                <p>
                    If you haven’t received any party invitations, nor heard about anything special
                    happening locally that night you may want to cast a wider net for New Years Eve
                    events in your area (or at least close enough that you don’t mind the travel time.)
                    Knowing ahead of time where you would like to be will greatly reduce your stress
                    when trying to find a date for the evening.</p>
                <p>
                    Those who are choosing to stay at home for the evening may enjoy the wide range
                    of parties being attended via the internet. Spending New Years online is not only
                    great for the budget, but may prove to be just the right place to meet someone if
                    you haven’t had any luck lately, as millions of people get together to chat during
                    this festive evening.<br>
                    <strong>&nbsp;</strong><strong>What you’ll wear:</strong></p>
                <p>
                    Most people are living on a rather tight budget these days, so don’t feel obligated
                    to dress in&nbsp;an expensive outfit simply because of the occasion. It is important,
                    however that you do look</p>
                <p>
                    <img class="size-medium wp-image-70 alignleft" title="shutterstock_7519639" alt="" src="/images/img/shutterstock_7519639.jpg?w=300&amp;h=200" width="300" height="200"></p>
                <p>
                    your best, so if you have any good party clothes or can afford a new set this might
                    be the time to try some things on and make a trial run of your outfit.<br>
                    Consider that during the course of the evening you may find yourself participating
                    in the traditional party events. You may be compelled to sing and dance or play
                    some New Years Eve games that may be inhibited by your choice in clothing. Again,
                    knowing ahead of time what may lie in store for you can be a great way to avoid
                    minor dating disasters.</p>
                <p>
                    The holidays will try to add some extra pounds to your waistline so it is also vital
                    that you either plan for the extra weight or fight back when those tempting confections
                    try to tack on some pounds. Restricting your diet may not be the easiest thing around
                    this time of year, but your future romance may have you feeling glad you did.</p>
                <p>
                    <strong>Who you’ll take:</strong></p>
                <div>
                    By now you have hopefully narrowed down how you’ll be spending the evening, naturally
                    the next step is to know who with. Finding just the right person to spend such a
                    special occasion with isn’t always easy, but rest assured, you have more options
                    than ever before.<br>
                    <img class="alignright size-medium wp-image-73" title="shutterstock_90194722" alt="" src="/images/img/shutterstock_90194722.jpg?w=300&amp;h=231" width="300" height="231">When heading out to meet new people you already have
                    the most wonderful invitation to offer should you find someone who seems right for
                    you, this is a nice perk to have when dating. Offering an invitation to a New Years
                    bash is a great way to add a little depth to your new relationship, even if you’re
                    only looking for something casual.If the clubs are offering up no real prospects
                    it might be time to make use of the digital age in your search.&nbsp; During this
                    season, thousands of people join online dating communities in the hope that they
                    will find the right person to spend this and perhaps many other New Year’s evening
                    with. Making good use of the dating services offered by so many of the top ranked
                    sites may have you meeting just the right person in no time.Searching through online
                    dating personals and profiles can also help to speed up your search and help you
                    to meet local singles who you might have otherwise&nbsp;never have had the chance
                    to know.&nbsp; Many sites allow you to browse for free before you commit to anything
                    and this may give you an idea of what possibilities this method can offer. Once
                    you meet and feel comfortable with your new romantic interest, you can offer up
                    your invite and welcome in the New Year together.<p>
                    </p>
                </div>
                <div>
                    <div>
                        <div>
                            <strong>Why you’ll be happy you did:</strong>Whether you find your romance at the
                            local pub or an online dating chat room, it is important that you take the time
                            to make the night a special one. By planning ahead and finding just the right person
                            you may be heading for one of the best nights of your life.As always, it is important
                            to remember to be safe on this wild party night. It should be a priority not only
                            to watch your alcohol intake, but to arrange for your transportation before you
                            begin the party.&nbsp; Practicing commonsense,&nbsp;dating safety tips&nbsp;is also
                            recommended as some people are apt to do rather crazy things during this night.<p>
                            </p>
                            <p>
                                Content provided by Villagematchmaker</p>
                            <p>
                                <span style="font-size: small;"><span style="line-height: normal;">
                                    <br>
                                </span></span>
                            </p>
                        </div>
                    </div>
                </div>
                <br>
            </div>
        </div>
        <div class="article">
            <h2>
                Sex positions you need to try!</h2>
            <p class="stt-date">
                25th Nov 2011</p>
            <div>
                <div style="text-align: left;">
                    Hey Ladies and Gentlemen,</div>
                <div style="text-align: left;">
                </div>
                <div style="text-align: left;">
                    This is one post you NEED to read, if you don’t your going to JAIL…
                    <img class="wp-smiley" alt=":)" src="/images/img/emotions/icon_smile.gif">
                    I’ve been doing some research and ive discovered a some positions which you HAVE
                    to try. I know what im doing for the next few weeks
                    <img class="wp-smiley" alt=":P" src="/images/img/emotions/icon_razz.gif">
                </div>
                <div style="text-align: left;">
                </div>
                <div style="text-align: left;">
                    These positions are something else and &nbsp;i love the creativity, i thought i
                    had explored it all, how narrow minded i was…</div>
                <div style="text-align: left;">
                </div>
                <div style="text-align: left;">
                    Please Holla username: “Snoop!” if you have tried these and loved it, I wanna hear
                    allllll about it!</div>
                <div style="text-align: left;">
                </div>
                <p style="text-align: left;" align="center">
                    <strong>1.&nbsp;Ladder Lovin’</strong></p>
                <p style="text-align: center;" align="center">
                    &nbsp;<a href="/images/img/ladderloving.jpg"><img class="wp-image-28 aligncenter" title="ladderloving" alt="" src="/images/img/ladderloving.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                <p style="text-align: left;" align="center">
                    “This position requires some maneuvering. Climb down to the second-to-last rung
                    of the pool ladder. Do a 180, holding the rails, so your back is to the wall. Lean
                    forward and spread your legs so your guy can lower himself behind you and place
                    his feet between your legs on the rung below you. Adjust your bodies so he can slip
                    himself inside you.”</p>
                <p style="text-align: left;" align="center">
                    <strong>2.&nbsp;V For Vixen</strong></p>
                <p style="text-align: center;">
                    <img class="wp-image-29 aligncenter" title="VforVixen" alt="" src="/images/img/vforvixen.jpg?w=270&amp;h=270" width="270" height="270"></p>
                <div>
                    <p style="text-align: left;" align="center">
                        <strong>&nbsp;</strong></p>
                    <p style="text-align: left;" align="center">
                        “Sit on a counter and have your man stand facing you. His legs should be slightly
                        bent, spaced 3 feet apart. With your arms on his shoulders and his arms around your
                        lower back, slowly pull your right leg up and prop your right foot on his left shoulder.
                        Then pull your left leg up and prop your left foot on his right shoulder.”</p>
                    <p style="text-align: left;" align="center">
                        <strong>3.&nbsp;Sideways Samba</strong></p>
                    <p style="text-align: center;" align="center">
                        &nbsp;<a href="/images/img/sidewayssamba.jpg"><img class="wp-image-30 aligncenter" title="SidewaysSamba" alt="" src="/images/img/sidewayssamba.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                    <p style="text-align: left;" align="center">
                        “You lie on your side on the bed or floor, turned away from your guy with your legs
                        straight out in front of you at a ninety-degree angle to your torso (so you make
                        an L shape). Your guy lies behind you on his side in a modified spoon position,
                        lines up his genitals with yours, then raises his torso with his arms, placing his
                        topmost hand on the other side of your body next to your chest. Entering you, he
                        controls the motion as he moves in and out of you.</p>
                    <p style="text-align: left;" align="center">
                        <strong>4.&nbsp;Bootyful View</strong></p>
                    <p style="text-align: center;" align="center">
                        <a href="/images/img/bootyfulview.jpg">
                            <img class="wp-image-31 aligncenter" title="BootyfulView" alt="" src="/images/img/bootyfulview.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                    <p style="text-align: left;" align="center">
                        “Have your man sit up on the bed so that his legs are extended horizontally toward
                        the foot of the bed. Turn around and straddle him with your back toward him and
                        then lower yourself onto his erect penis. Extend your legs back so they are almost
                        behind him, relaxing your torso onto the bed between his feet. Slide up and down
                        and use his feet for leverage.”</p>
                    <p style="text-align: left;" align="center">
                        <strong>5.&nbsp;Thigh Master</strong></p>
                    <p style="text-align: center;" align="center">
                        &nbsp;<a href="/images/img/thighmaster1.jpg"><img class="wp-image-33 aligncenter" title="ThighMaster" alt="" src="/images/img/thighmaster1.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                    <p style="text-align: left;" align="center">
                        “Your guy lies on his back, one leg outstretched and the other bent, knee pointing
                        upward. You straddle his body sideways with your back turned slightly to his face,
                        hold on to his knee, and lower yourself onto his penis. In this pose, your stomach
                        is almost touching his bent knee; use it for support and leverage as you rock back
                        and forth, and up and down.”</p>
                    <p style="text-align: right;" align="center">
                        <strong>&nbsp;</strong></p>
                    <p style="text-align: right;" align="center">
                        <strong></strong><strong>&nbsp;</strong></p>
                    <p style="text-align: left;" align="center">
                        <strong>6.&nbsp;The Dirty Dangle</strong></p>
                    <p style="text-align: center;" align="center">
                        <a href="/images/img/thedirtydangle.jpg">
                            <img class="wp-image-34 aligncenter" title="TheDirtyDangle" alt="" src="/images/img/thedirtydangle.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                    <p style="text-align: left;" align="center">
                        “Begin by lying on your back at the foot end of the bed. Have him mount you missionary
                        style and when youre both close to climax, inch toward the edge of the bed until
                        your head, shoulders, and arms hang backward over the side.&nbsp;Then tell him to
                        keep on thrusting.”</p>
                    <p style="text-align: left;" align="center">
                        <strong>7.&nbsp;Arc de Triomph</strong></p>
                    <p style="text-align: center;" align="center">
                        <a href="/images/img/arcdetriomph.jpg">
                            <img class="wp-image-35 aligncenter" title="ArcdeTriomph" alt="" src="/images/img/arcdetriomph.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                    <p style="text-align: left;" align="center">
                        “Have your man sit on the bed with his legs extended in front of him. Crawl up to
                        him on your knees and straddle him, lowering yourself onto his erect penis. Once
                        youre comfortable, arch into a back bend but be careful not to strain your lower
                        back. Rest your head between his legs on the bed and reach your hands back to grab
                        hold of his ankles or feet. Thats when he leans forward and the fun begins.”</p>
                    <p style="text-align: left;" align="center">
                        <strong>8.&nbsp;The Pinwheel</strong></p>
                    <p style="text-align: center;" align="center">
                        &nbsp;<a href="/images/img/thepinwheel.jpg"><img class="wp-image-36 aligncenter" title="ThePinwheel" alt="" src="/images/img/thepinwheel.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                    <p style="text-align: left;" align="center">
                        “You and your partner lie on your sides facing the same direction. First, you lower
                        your crotch onto his, wrapping your legs around either side of his torso. Your arms
                        should be stretched out behind you supporting your weight. He then encircles your
                        waist with his legs and grips your upper thighs and thrusts gently.”</p>
                    <p style="text-align: left;" align="center">
                        <strong>9.&nbsp;The G-Force</strong></p>
                    <p style="text-align: center;" align="center">
                        &nbsp;<a href="/images/img/thegeforce1.jpg"><img class="wp-image-38 aligncenter" title="TheGeforce" alt="" src="/images/img/thegeforce1.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                    <p style="text-align: left;" align="center">
                        Lie down on your back and pull your knees close to your chest. Ask your guy to kneel
                        in front of you, grabbing hold of your feet with his hands. Have him penetrate you,
                        thrusting forward from his hips. Looking to add even more “God-thats-good action?
                        Put your feet on his chest and have him hold on to your hips itll give him extra
                        control and let him plunge even farther.”</p>
                    <p style="text-align: left;" align="center">
                        <strong>10.&nbsp;Bucking Bronco</strong></p>
                    <p style="text-align: center;" align="center">
                        <a href="/images/img/bucking-bronco.jpg">
                            <img class="wp-image-39 aligncenter" title="Bucking Bronco" alt="" src="/images/img/bucking-bronco.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                    <p style="text-align: left;" align="center">
                        “He lies flat on his back with his knees bent and legs spread apart. Facing him,
                        get on top and slowly lower yourself onto his shaft, keeping your knees bent and
                        your legs outside his arms. Then lean back and support yourself on your palms as
                        he thrusts his hips up and down.”</p>
                    <p style="text-align: left;" align="center">
                        <strong>11.&nbsp;The Wanton Wheelbarrow</strong></p>
                    <p style="text-align: center;" align="center">
                        <a href="/images/img/thewanton.jpg">
                            <img class="wp-image-40 aligncenter" title="TheWanton" alt="" src="/images/img/thewanton.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                    <p style="text-align: left;" align="center">
                        “Start by standing and facing a bed or a chair. Bend over until your head and arms
                        are resting on its surface. Have your man stand behind you and grab one of your
                        ankles. Make sure to keep your knee slightly bent as you shift your weight to the
                        leg that’s still on the ground. Lifting your foot to rest near his hip, he should
                        enter you from behind.”</p>
                    <p style="text-align: left;" align="center">
                        <strong>12.&nbsp;Torrid Tug-of-War</strong></p>
                    <p style="text-align: center;" align="center">
                        <a href="/images/img/torridtugowar.jpg">
                            <img class="wp-image-41 aligncenter" title="Torridtugowar" alt="" src="/images/img/torridtugowar.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                    <p style="text-align: left;" align="center">
                        “Have him sit cross-legged on the floor or the bed before you straddle him. Lower
                        yourself onto his penis and wrap your legs around his back. As youre sitting face-to-face,
                        grab each others elbows and lean back against the other persons weight like a coy
                        tug-of-war game. If youre limber enough, you might be able to tilt your head far
                        enough back to rest it on the floor. Try to keep as still as possible, concentrating
                        on you and your mans bodily connection.”</p>
                    <p style="text-align: left;" align="center">
                        <strong>13.&nbsp;The Linguini</strong></p>
                    <p style="text-align: center;" align="center">
                        &nbsp;<a href="/images/img/thelinguini.jpg"><img class="wp-image-42 aligncenter" title="TheLinguini" alt="" src="/images/img/thelinguini.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                    <p style="text-align: left;" align="center">
                        “Lie on your side, putting a pillow under your head for extra support. Your man
                        kneels directly behind your butt, leaning ever-so-slightly over your body. He should
                        push one of his knees between your legs, positioning his body so he can penetrate
                        you. He places one hand on your back to help support himself as he goes for the
                        plunge. The key to your pleasure is keeping your limbs as limp as a noodle.”</p>
                    <p style="text-align: right;" align="center">
                        <strong>&nbsp;</strong></p>
                    <p style="text-align: left;" align="center">
                        <strong>14.&nbsp;Bed Spread</strong></p>
                    <p style="text-align: center;" align="center">
                        <a href="/images/img/bedspread.jpg">
                            <img class="wp-image-43 aligncenter" title="BedSpread" alt="" src="/images/img/bedspread.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                    <p style="text-align: left;" align="center">
                        “Bend over the side of the bed so your stomach and breasts are against the mattress
                        and your feet are on the floor, legs spread comfortably. As your guy penetrates
                        you from behind, he lifts your legs from just above the knees, holds them apart,
                        and thrusts.”</p>
                    <p style="text-align: left;" align="center">
                        <strong>15.&nbsp;Sexy Scissors</strong></p>
                    <p style="text-align: center;" align="center">
                        &nbsp;<a href="/images/img/sexyscissors.jpg"><img class="wp-image-44 aligncenter" title="SexyScissors" alt="" src="/images/img/sexyscissors.jpg?w=270&amp;h=270" width="270" height="270"></a></p>
                    <p style="text-align: left;" align="center">
                        “You lie faceup on a desk or tabletop with your hips perched on the very edge. Raise
                        your legs to an eye-popping 90-degree angle, then have your guy grab your ankles.
                        He extends his arms out to his sides, and as your legs are spread-eagle, he enters
                        you while standing. Next, he starts alternately crossing and spreading your legs
                        like scissors, opening and closing as he thrusts.”</p>
                </div>
                <br>
            </div>
        </div>
        <div class="article">
            <h2>
                Snoops Dating Tips</h2>
            <p class="stt-date">
                3rd Nov 2011</p>
            <div>
                <p>
                    Hey all my fellow hotties!!</p>
                <p>
                    I hope our site is serving you well, ive been browsing male and female profiles
                    and i have noticed there are a lot of people breaking some golden rules to getting
                    laid.I have some sensible advice too which involves your safety (girls and guys).Always
                    be safe, never give out too much personal info which may include your home number&nbsp;address
                    etc. Always meet in a public place and make sure your online lover has a recent
                    photo!</p>
                <p>
                    <img class="size-medium wp-image-14 alignright" title="Dating" alt="" src="/images/img/dating.jpg?w=147&amp;h=147" width="147" height="147"></p>
                <p>
                    <strong>Profile Content</strong></p>
                <p>
                    Your profile and your photo are the two key elements of your success with this dating
                    stuff. Never have any negativity on your profile. Avoid it all costs! “I’m&nbsp;Lonely,
                    I can’t believe&nbsp;im&nbsp;doing this” etc….leave it at the door! Providing you
                    do that, and make your profile seem interesting,then you should be onto winner.
                    The girls will love it! Actually same for the girls! The&nbsp;men like that too!</p>
                <div>
                    <p>
                        <strong>Your mug shot
                            <img class="wp-smiley" alt=":)" src="/images/img/emotions/icon_smile.gif">
                        </strong>
                    </p>
                    <p>
                        Face it – when doing a search on an online dating service the first thing that grabs
                        your attention is the photo. This is the single most important element to getting
                        people to view&nbsp;that great profile you’ve written (see last tip). These days,
                        generic photos won’t cut it. You need to determine what colors look best on you,
                        dress nice, be clean cut, and have someone&nbsp;try some different stuff people.take
                        various photos of you that are fun and lively. When I changed my photo from a posed
                        shot to a shot of me with a horse, the number of people emailing me or showing an
                        interest quadrupled. It also provided a great ice breaker and talking point when
                        someone emailed me. Mix it up,</p>
                    <p>
                        Check this out for an example! In the first you cannot even see me except for the
                        fact that im in a boat in a kiddies pool. The Second, you can see my face and my
                        what a good looking chap i am lmao!</p>
                    <p>
                        Bad Photo (lol): &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Better
                        Photo:</p>
                    <p style="text-align: center;">
                        <img class="alignleft size-medium wp-image-18" title="37311_10150214840065571_581580570_13178112_3972655_n" alt="" src="/images/img/37311_10150214840065571_581580570_13178112_3972655_n.jpg?w=210&amp;h=150" width="210" height="150"><a href="/images/img/149957_10150327381970571_581580570_15833317_7379861_n.jpg"><img class="size-medium wp-image-22 aligncenter" title="149957_10150327381970571_581580570_15833317_7379861_n" alt="" src="/images/img/149957_10150327381970571_581580570_15833317_7379861_n.jpg?w=194&amp;h=146" width="194" height="146"></a></p>
                    <p style="text-align: left;">
                        <a href="/images/img/149957_10150327381970571_581580570_15833317_7379861_n.jpg">
                            <br>
                            <strong><span style="color: rgb(0, 0, 0);" class="Apple-style-span">Your first email
                                &nbsp; &nbsp;&nbsp;</span></strong><img class="size-thumbnail wp-image-20 alignnone" title="c-schmitz-closed-envelope-clip-art" alt="" src="/images/img/c-schmitz-closed-envelope-clip-art.jpg?w=54&amp;h=35" width="54" height="35"></a></p>
                    <p style="text-align: left;">
                        Your first email to someone you’re interested in is the most important one you’ll
                        ever write because it will help determine whether or not they write back. I cannot
                        stress enough how “hey your hot, i want your pussy” is not going to get you laid.
                        It’s important to personalize your introductory email and spend more time asking
                        questions (based on the other person’s profile) than providing information about
                        yourself. Throwing a compliment in doesn’t hurt either (i.e. “I love your smile”
                        or “your profile is one of the best I’ve read”).</p>
                    <p>
                        <strong>Your first date
                            <img class="wp-smiley" alt=":P" src="/images/img/emotions/icon_razz.gif">
                            &nbsp;</strong><a href="/images/img/romance-couplekissingheart.gif"><img class="alignnone size-thumbnail wp-image-21" title="romance-couplekissingheart" alt="" src="/images/img/romance-couplekissingheart.gif?w=49&amp;h=54" width="49" height="54"></a></p>
                    <p>
                        Your actual date is going to shape the other person’s opinion more than anything
                        else to date. Thus it’s important that you make a great first impression. As the
                        saying goes, you never get a second chance to make a great first impression. Be
                        confident on your date. Confidence is one of the biggest attractions you can posses,
                        don’t over do it though
                        <img class="wp-smiley" alt=":P" src="/images/img/emotions/icon_razz.gif">
                    </p>
                    <p>
                        So, we’ve covered some basic steps, i hope i’ve helped and as always
                        <img class="wp-smiley" alt=":)" src="/images/img/emotions/icon_smile.gif">
                    </p>
                    <p>
                        Peace out.</p>
                    <p>
                        Snoop</p>
                </div>
                <br>
            </div>
        </div>
        <div class="article">
            <h2>
                Changing the way you date, one step at a time :)</h2>
            <p class="stt-date">
                2nd Nov 2011</p>
            <div>
                <p>
                    Welcome to Snoopys Top Tips!
                </p>
                <p>
                    I am really excited to finally have this blog setup! It’s been in the pipeline for
                    so long and now I’m here to bring you the latest news, updates, advice and guidance….you
                    know what, I’ll literally be giving you everything and anything I think is relevant
                    and probably throwing in some irrelevant too
                    <img class="wp-smiley" alt=":D" src="/images/img/emotions/icon_biggrin.gif">
                </p>
                <p>
                    Remember! I’m your friend, if you need any help on the site be sure to check my
                    blog or email Support@pinkmeets.com.</p>
                <p>
                    I’m gonna be here as your eyes and ears bringing you latest announcements on our
                    awesome new features, the newest and hottest fashion tips, letting you know the
                    latests trends and hmhmm Sex. Yes, we will be covering positions, products, the
                    lot!</p>
                <p>
                    It’s going to be fun guys, if you have any requests at all for ANYTHING I will do
                    my best to fit it in. Just comment below</p>
                <p>
                    So I bet your really really excited now
                    <img class="wp-smiley" alt=":D" src="/images/img/emotions/icon_biggrin.gif">
                    Stay Tuned!!</p>
                <p>
                    Much love!</p>
                <p>
                    Snoopy</p>
                <br>
            </div>
        </div>
    </div>
