<div class="regBox2 bgRadBox">
	
<?php $this->widget('application.components.UserRegistrationStep2FormWidget'); ?>

</div>